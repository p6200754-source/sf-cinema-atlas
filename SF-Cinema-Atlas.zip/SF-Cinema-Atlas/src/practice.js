// Public resources only. Manual edits take place in the downloaded local project.
export async function initPractice({atlas,geo,streets,palette}){
 const C=window.AtlasCore,host=document.querySelector('#practice-resources');
 host.innerHTML=`<div class="offline-grid"><div class="offline-tasks">
 <article class="offline-task"><span class="eyebrow">TASK 01 / MAP COLORIST</span><h2>Recolor the city.</h2><p>In your local map.js, change the five palette colors. Choose an ordered light-to-dark palette using HEX, RGB, HSL or a D3 color scheme.</p><p lang="zh">在本地修改五档配色。观察地图与图例是否同步变化，以及记录数量是否保持不变。</p><p class="task-outcome">Observe / 观察：same records, different colors.</p></article>
 <article class="offline-task"><span class="eyebrow">TASK 02 / TIME TRAVEL</span><h2>Choose a release year.</h2><p>In your local map.js, choose a year and the exact-year or since-year mode. Save and compare the updated neighborhood densities.</p><p lang="zh">在本地选择一个发行年份，筛选“仅该年”或“该年及之后”。保存后比较街区颜色和记录数。</p><p class="task-outcome">Observe / 观察：new filter, recalculated records and density.</p></article>
 <div class="resource-note"><b>Using a fresh CSV / 使用新下载的数据</b><p>Replace data/film_locations.csv with the complete official CSV, keeping this filename. The project reads the actual rows. A newer export may differ from the website snapshot downloaded on 24 October 2026.</p><p lang="zh">替换练习项目中的 data/film_locations.csv，保持文件名一致。官方数据若已更新，数量可能与网站快照不同。安装 Live Server 需联网；项目所需的 D3 与边界文件已包含。</p></div>
 </div><figure class="offline-reference"><div class="reference-heading"><span class="eyebrow">REFERENCE / ALL YEARS</span><h2>The city, before your edit.</h2></div><svg id="practice-reference-map" role="img" aria-label="Reference choropleth using the website snapshot"></svg><figcaption><b>Location records / km²</b><div id="practice-reference-legend" class="reference-legend"></div><p id="practice-reference-note"></p><a href="#explore">Explore the interactive map ↗</a></figcaption></figure></div>`;
 const svg=d3.select('#practice-reference-map'),width=600,height=540;
 const stats=C.aggregate(atlas.records,geo.features),color=C.makeColorScale(atlas.meta.thresholds,palette),{path}=C.makeProjection(geo.features,width,height,24);
 svg.attr('viewBox',`0 0 ${width} ${height}`);
 C.drawNeighborhoods({layer:svg.append('g'),features:geo.features,stats,path,color,interactive:false});
 svg.append('path').datum(streets).attr('d',path).attr('fill','none').attr('stroke','#f4efe5').attr('stroke-width',.6).attr('opacity',.7);
 document.querySelector('#practice-reference-legend').innerHTML=palette.map((c,i)=>`<span><i style="background:${c}"></i>${C.thresholdLabel(i,atlas.meta.thresholds)}</span>`).join('');
 const assigned=[...stats.values()].reduce((sum,s)=>sum+s.records,0);
 document.querySelector('#practice-reference-note').textContent=`${assigned.toLocaleString()} of ${atlas.records.length.toLocaleString()} records assigned · fixed thresholds · grey = zero · area includes mapped water.`;
}
