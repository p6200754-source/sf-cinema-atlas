export async function initPractice({atlas,geo,streets,coreSource,palette}){
 const $=s=>document.querySelector(s), E=window.AtlasCore.escapeHTML;
 const editor=$('#code-editor'); let frame=$('#practice-preview'),candidate=null;
 const d3Source=await fetch('vendor/d3.v7.min.js').then(r=>{if(!r.ok)throw Error('Local D3 unavailable');return r.text();});
 const starter=`// map.js — 全部可编辑；只修改下面的值即可运行。
// COLOR / 五种颜色由浅到深；支持 HEX、rgb()、rgba()、hsl()。
const palette = ${JSON.stringify(palette)};
// 也可以把上面的数组替换为 d3.schemeOranges[5]。

// YEAR / null = 全部年份；2019 = 筛选 2019 年。
const YEAR = null;
// "exact" = 仅该年；"since" = 该年及之后。
const YEAR_MODE = "exact";

// Collect / 与首页共用筛选、街区汇总和密度计算。
const range = YEAR === null ? { key: "all" } : {
  start: YEAR,
  end: YEAR_MODE === "since" ? Infinity : YEAR
};
const filtered = AtlasCore.filterRecords(records, range);
const stats = AtlasCore.aggregate(filtered, features);

// Project
const { projection, path } = AtlasCore.makeProjection(
  features, width, height, 24
);
// Color
const color = AtlasCore.makeColorScale(thresholds, palette);
// Connect
AtlasCore.drawNeighborhoods({
  layer, features, stats, path, color, interactive: false
});
finish({ filtered, stats, palette, path, color, projection,
  yearLabel: YEAR === null ? "All years" : YEAR_MODE === "since"
    ? YEAR + " onward" : String(YEAR)
});
`;
 let task=1,saved={},token=0,watchdog,pending={};
 // Start the revised classroom template separately; preserve older drafts in v3.
 try{saved=JSON.parse(localStorage.getItem('sf-cinema-map-v4')||'{}');}catch{}
 const save=()=>{saved[task]=editor.value;try{localStorage.setItem('sf-cinema-map-v4',JSON.stringify(saved));}catch{}};
 const bar=document.querySelector('.editor-panel>.panel-bar');bar.innerHTML='<div class="js-file-tabs"><button type="button" aria-label="map.js, fully editable"><span>JS</span> map.js <small>EDITABLE</small></button></div>';
 const hint=document.createElement('div');hint.className='js-editor-guide';hint.innerHTML='<b>map.js</b> · Edit any code, then Run. <span lang="zh">直接修改 palette、YEAR 和 YEAR_MODE 的值。不要重复粘贴 const 声明；下方绘图代码也可自由编辑。</span>';
 bar.after(hint);const errorBox=document.createElement('div');errorBox.id='editor-error';errorBox.className='editor-error';errorBox.setAttribute('role','alert');errorBox.hidden=true;hint.after(errorBox);
 const shell=document.createElement('div');shell.className='js-editor-shell';editor.before(shell);shell.innerHTML='<div class="code-gutter" aria-hidden="true"><pre></pre></div><div class="code-paint" aria-hidden="true"><pre></pre></div>';shell.append(editor);
 const paint=shell.querySelector('.code-paint pre'),gutter=shell.querySelector('.code-gutter pre');
 function decorateCode(){
  const value=editor.value;let out='',last=0;const rx=/\/\/[^\n]*|\b(?:const|let|return|false|true|null)\b|\b\d+\b|\b(?:d3|AtlasCore|palette|START_YEAR)\b/g;
  for(const m of value.matchAll(rx)){out+=E(value.slice(last,m.index));out+=`<span class="${m[0].startsWith('//')?'js-comment':/^\d/.test(m[0])?'js-number':['const','let','return','false','true','null'].includes(m[0])?'js-keyword':'js-name'}">${E(m[0])}</span>`;last=m.index+m[0].length;}
  paint.innerHTML=out+E(value.slice(last))+'\n';gutter.textContent=value.split('\n').map((_,i)=>i+1).join('\n');syncScroll();
 }
 function syncScroll(){paint.style.transform=`translate(${-editor.scrollLeft}px,${-editor.scrollTop}px)`;gutter.style.transform=`translateY(${-editor.scrollTop}px)`;}
 editor.addEventListener('scroll',syncScroll);
 const tasks=[{id:1,title:'Map colorist',goal:'Give the atlas a warm orange palette.',hint:'修改 palette 的五个颜色值，或将整个数组替换为 d3.schemeOranges[5]。支持 HEX、RGB、RGBA、HSL。',check:'Five ordered orange colors. The legend changes with the map; record counts stay the same.'},{id:2,title:'Time travel',goal:'Show titles released from 2000 onward.',hint:`把 YEAR 改为 2000，把 YEAR_MODE 改为 "since"；仅看 2019 年则设 YEAR = 2019、YEAR_MODE = "exact"。筛选的是发行年份。`,check:'The label reads “2000 onward”, and record totals are recalculated. Find one matching title in Explore.'}];
 $('#tasks').innerHTML=tasks.map(t=>`<article class="task-card" data-task="${t.id}"><button class="task-select" data-select-task="${t.id}" aria-pressed="false"><span class="eyebrow">TASK 0${t.id} / ${t.id===1?'COLOR':'TIME'}</span><h2>${t.title}</h2></button><p>${t.goal}</p><ol class="task-steps"><li>Edit <b>map.js</b> and click <b>Locate code</b>。</li><li>Manually replace the line below / 手动修改下列代码。</li><li>Click <b>Run code</b>, then compare / 运行并观察。</li></ol><div class="task-change"><span>BEFORE / 修改前</span><code>${t.id===1?`const palette = ${JSON.stringify(palette)};`:'const YEAR = null;'}</code><span style="margin-top:10px">AFTER / 修改后</span><code class="after">${t.id===1?'const palette = d3.schemeOranges[5];':'const YEAR = 2000; const YEAR_MODE = "since";'}</code></div>${t.id===1?`<div class="task-palette">${d3.schemeOranges[5].map(c=>`<span style="background:${c}"></span>`).join('')}</div>`:''}<p><b>Example result:</b> ${t.check}</p><div class="task-controls"><button data-locate-task="${t.id}">Locate code</button><button data-hint="${t.id}" aria-expanded="false">Show hint</button></div><div class="hint" id="hint-${t.id}" hidden>${E(t.hint)}</div></article>`).join('')+`<p class="archive-note">Switching tasks keeps each edit separately. Reset restores only the current task. <span lang="zh">切换保留修改，重置只影响当前题。</span></p>`;
 document.querySelectorAll('[data-select-task]').forEach(b=>b.onclick=()=>switchTask(+b.dataset.selectTask));
 document.querySelectorAll('[data-locate-task]').forEach(b=>b.onclick=()=>{if(task!==+b.dataset.locateTask)switchTask(+b.dataset.locateTask);locate(task===1?'const palette =':'const YEAR =');});
 document.querySelectorAll('[data-hint]').forEach(b=>b.onclick=()=>{const hint=$(`#hint-${b.dataset.hint}`);hint.hidden=!hint.hidden;b.setAttribute('aria-expanded',String(!hint.hidden));b.textContent=hint.hidden?'Show hint':'Hide hint';});
 function locate(text){const match=editor.value.match(new RegExp('^'+text,'m'));const pos=match?.index??-1;if(pos<0)return;const line=editor.value.lastIndexOf('\n',pos)+1,end=editor.value.indexOf('\n',pos);editor.focus();editor.setSelectionRange(line,end<0?editor.value.length:end);editor.scrollTop=Math.max(0,editor.value.slice(0,pos).split('\n').length*20-100);}
 function switchTask(id){if(editor.value)save();task=id;editor.readOnly=false;editor.setAttribute('aria-label','Editable D3 JavaScript');editor.value=saved[task]??starter;decorateCode();document.querySelectorAll('[data-task]').forEach(el=>el.classList.toggle('selected',+el.dataset.task===task));document.querySelectorAll('[data-select-task]').forEach(el=>el.setAttribute('aria-pressed',String(+el.dataset.selectTask===task)));$('#task-result').textContent='Free exploration: edit any code and run to see the result.';$('#task-result').className='task-result';run(false);}
 editor.addEventListener('input',()=>{decorateCode();save();$('#run-status').textContent='Edited. Run code to update the preview.';});
 editor.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key==='Enter'){e.preventDefault();run(true);}if(e.key==='Tab'){e.preventDefault();if(!editor.readOnly){editor.setRangeText('  ',editor.selectionStart,editor.selectionEnd,'end');decorateCode();save();}}});
 $('#run-code').onclick=()=>run(true);
 $('#rebuild-preview').onclick=()=>run(false);
 $('#reset-code').onclick=()=>{editor.value=starter;decorateCode();save();$('#task-result').textContent='Task reset. Make your edit and run again.';$('#task-result').className='task-result';run(false);};
 $('#export-code').onclick=()=>{const blob=new Blob([editor.value],{type:'text/javascript'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='map.js';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);};
 window.addEventListener('atlas-locate',e=>{setTimeout(()=>{const pos=editor.value.indexOf(`// ${String(e.detail).charAt(0).toUpperCase()+String(e.detail).slice(1)}`);editor.focus();editor.setSelectionRange(Math.max(0,pos),Math.max(0,editor.value.indexOf('\n',pos)));editor.scrollTop=Math.max(0,editor.value.slice(0,pos).split('\n').length*22-50);},50);});
 const serial=x=>JSON.stringify(x).replaceAll('<','\\u003c');
 function run(check){
  $('#editor-error').hidden=true;save();token++;const current=token;const source=saved[task]??starter;pending={check,task,code:source};if(candidate){candidate.remove();candidate=null;}clearTimeout(watchdog);$('#run-status').className='run-status';$('#run-status').textContent='Running in an isolated preview…';if(check){$('#task-result').textContent='Running your JavaScript…';$('#task-result').className='task-result';}
  candidate=document.createElement('iframe');candidate.title='Pending D3 preview';candidate.setAttribute('sandbox','allow-scripts');candidate.hidden=true;frame.after(candidate);
  const script=`const payload=${serial({records:atlas.records,features:geo.features,thresholds:atlas.meta.thresholds,streets})};
const runId=${current};
function send(type,data){parent.postMessage({atlasPreview:true,runId,type,...data},'*');}
window.addEventListener('error',e=>send('error',{message:e.message}));
const records=payload.records,features=payload.features,thresholds=payload.thresholds;
const width=600,height=520;
const svg=d3.select('#map').attr('viewBox',\`0 0 \${width} \${height}\`);
const layer=svg.append('g');let report={};
const finish=({filtered,stats,palette,path,color,projection,yearLabel})=>{
 if(path)layer.append('path').datum(payload.streets).attr('d',path).attr('fill','none').attr('stroke','#f4efe5').attr('stroke-width',.7).attr('opacity',.65).attr('pointer-events','none');
 const legend=document.querySelector('#legend');legend.replaceChildren();
 const colors=color?.range?color.range():(Array.isArray(palette)?palette:[]);
 const breaks=color?.domain?color.domain():thresholds;
 colors.forEach((c,i)=>{const el=document.createElement('div');const sw=document.createElement('span');sw.style.background=c;el.append(sw,document.createTextNode(breaks.length===colors.length-1?AtlasCore.thresholdLabel(i,breaks):String(i+1)));legend.append(el);});
 if(filtered&&stats){
  const assigned=[...stats.values()].reduce((s,d)=>s+d.records,0);
  document.querySelector('#note').textContent=(yearLabel||'Custom filter')+' · '+assigned.toLocaleString()+' of '+filtered.length.toLocaleString()+' records assigned · '+(filtered.length-assigned).toLocaleString()+' unassigned · Area includes mapped water.';
  report={count:filtered.length,assigned};
 }
 if(stats&&path){
  layer.selectAll('.neighborhood').append('title').text(d=>{const v=stats.get(d.properties.name);return d.properties.name+' · '+v.records+' records · '+v.works+' titles · '+v.density.toFixed(1)+' records / km²';});
  layer.selectAll('.neighborhood').on('click',function(){layer.selectAll('.neighborhood').classed('selected',false);d3.select(this).classed('selected',true);});
  if(projection){
   const names=['Presidio','Mission','North Beach','Golden Gate Park','Outer Richmond','Bayview Hunters Point','Treasure Island','Sunset/Parkside'];
   layer.append('g').attr('pointer-events','none').selectAll('text').data(features.filter(f=>names.includes(f.properties.name))).join('text').attr('x',f=>projection(d3.geoCentroid(f))[0]).attr('y',f=>projection(d3.geoCentroid(f))[1]).attr('text-anchor','middle').attr('font-size',8).attr('fill','#263531').attr('paint-order','stroke').attr('stroke','#f5f4ef').attr('stroke-width',1.5).text(f=>f.properties.name);
  }
  const zoom=d3.zoom().scaleExtent([1,7]).on('zoom',e=>layer.attr('transform',e.transform));svg.call(zoom).on('wheel.zoom',null);
  document.querySelector('#plus').onclick=()=>svg.call(zoom.scaleBy,1.4);
  document.querySelector('#minus').onclick=()=>svg.call(zoom.scaleBy,1/1.4);
  document.querySelector('#home').onclick=()=>svg.call(zoom.transform,d3.zoomIdentity);
 }
 document.querySelector('#title').textContent='Location records / km² · fixed thresholds · grey = zero';
};
try{
${source}
send('success',report);
}catch(e){send('error',{message:e.message});}
`;
  candidate.srcdoc=`<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src data:; connect-src 'none'; form-action 'none'"><style>#controls{position:absolute;right:12px;top:12px;display:grid}#controls button{background:#f5f4ef;border:1px solid #b7c5bb;padding:7px 11px;color:#263531;cursor:pointer}body{margin:0;background:#f5f4ef;color:#263531;font:12px Georgia,serif}#map{width:100%;height:calc(100vh - 100px);min-height:200px;background:#d8e4e5;display:block}.selected{stroke:#263531!important;stroke-width:2!important}.neighborhood{cursor:pointer;vector-effect:non-scaling-stroke;stroke:#f4efe5;stroke-width:.8}#legend{display:flex;gap:4px;padding:7px 10px}#legend div{flex:1;font:10px monospace;text-align:center}#legend span{display:block;height:14px;margin-bottom:5px}#title{padding:10px 12px 0;font-size:14px}#note{padding:3px 12px 8px;font:10px sans-serif;line-height:1.5}</style></head><body><div id="controls"><button id="plus" aria-label="Zoom in">+</button><button id="minus" aria-label="Zoom out">−</button><button id="home" aria-label="Reset map">↺</button></div><svg id="map" aria-label="D3 neighborhood density preview"></svg><div id="title">JavaScript preview</div><div id="legend"></div><div id="note"></div><script>${d3Source.replaceAll('</script','<\\/script')}<\/script><script>${coreSource.replaceAll('</script','<\\/script')}<\/script><script>window.addEventListener('error',function(e){parent.postMessage({atlasPreview:true,runId:${current},type:'error',message:e.message},'*');});<\/script><script>${script.replaceAll('</script','<\\/script')}<\/script></body></html>`;
  watchdog=setTimeout(()=>{if(token===current){$('#run-status').textContent='No response from preview. Check your code or use Reset task and Rebuild.';$('#run-status').className='run-status error';}},8000);
 }
 window.addEventListener('message',e=>{
  if(e.source!==candidate?.contentWindow||!e.data?.atlasPreview||e.data.runId!==token)return;
  clearTimeout(watchdog);const data=e.data;
  if(data.type==='error'){const paletteName=pending.code?.replace(/\/\/[^\n]*/g,'').match(/d3\.(scheme\w+)/)?.[1];let message=String(data.message);if(message.includes('already been declared'))message+=' — 同名 const 重复声明：请修改原有变量的值，不要再添加一份声明。';if(paletteName&&!d3[paletteName])message=`d3.${paletteName} is not a D3 palette. Names are case-sensitive. Try d3.schemeOranges[5] or d3.schemeYlOrBr[5]. 色带名称无效，也可以使用自定义颜色数组。`;$('#run-status').textContent=`map.js error: ${message.slice(0,500)} Previous successful map retained.`;$('#editor-error').textContent=`${message.slice(0,500)} — 地图保留上次成功的结果，请修正后再运行。`;$('#editor-error').hidden=false;document.querySelector('.preview-panel .panel-bar b').textContent='Map preview · last valid result';candidate.remove();candidate=null;$('#run-status').className='run-status error';$('#task-result').textContent='JavaScript error. Correct it and run again; your previous preview is retained.';$('#task-result').className='task-result';return;}
  if(data.type!=='success')return;frame.remove();frame=candidate;candidate=null;frame.id='practice-preview';frame.title='Isolated D3 code preview';frame.hidden=false;document.querySelector('.preview-panel .panel-bar b').textContent='Map preview';
  $('#run-status').textContent=Number.isFinite(data.count)?`Ran successfully · ${data.count.toLocaleString()} filtered records · ${data.assigned.toLocaleString()} assigned to neighborhoods.`:'Ran successfully · Your JavaScript preview is ready.';
  if(pending.code!==(saved[task]??starter))$('#run-status').textContent='Saved code restored. Click Run code to apply your edits; preview shows the initial baseline.';
  $('#task-result').textContent='Code executed. Compare your result and keep exploring — there is no required answer. 运行成功，可继续自由尝试。';
  $('#task-result').className='task-result success';
 });
 // Establish a valid baseline before trying any saved code.
 const restored=saved[1];saved[1]=starter;switchTask(1);if(restored&&restored!==starter){saved[1]=restored;editor.value=restored;decorateCode();save();$('#run-status').textContent='Saved code restored. Run code to test them; the initial preview uses the baseline.';}
}
