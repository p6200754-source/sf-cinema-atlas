/* SF Cinema Atlas — shared data + D3 map core.
 * This file is loaded as a classic script before the app module, and is also
 * injected into the sandboxed practice preview by the parent page. Core map
 * functions are therefore identical in the atlas and in the editor preview.
 */
(function (global) {
  'use strict';

  const DENSITY_FALLBACK = 0;

  // [lesson:collect]
  function filterRecords(records, range) {
    if (!range || range.key === 'all') return records.slice();
    return records.filter(
      (d) => d.year !== null && d.year >= range.start && d.year <= range.end
    );
  }

  function aggregate(records, features) {
    const stats = new Map();
    for (const feature of features) {
      const name = feature.properties.name;
      stats.set(name, {
        name,
        areaKm2: feature.properties.areaKm2,
        records: 0,
        worksSet: new Set(),
        pointRecords: [],
        density: 0,
      });
    }
    const grouped = d3.rollup(records, rows => rows, d => d.neighborhood);
    for (const [name, rows] of grouped) {
      const entry = stats.get(name);
      if (!entry) continue;
      entry.records = rows.length;
      for (const record of rows) {
        entry.worksSet.add(record.workKey);
        if (record.pointMapped) entry.pointRecords.push(record);
      }
    }
    for (const entry of stats.values()) {
      entry.works = entry.worksSet.size;
      entry.density = entry.areaKm2 ? entry.records / entry.areaKm2 : 0;
    }
    return stats;
  }
  // [/lesson:collect]

  // [lesson:project]
  function makeProjection(features, width, height, padding) {
    const collection = { type: 'FeatureCollection', features };
    const projection = d3
      .geoMercator()
      .fitExtent(
        [
          [padding, padding],
          [width - padding, height - padding],
        ],
        collection
      );
    const path = d3.geoPath(projection);
    return { projection, path, collection };
  }
  // [/lesson:project]

  // [lesson:color]
  function makeColorScale(thresholds, palette) {
    return d3.scaleThreshold().domain(thresholds).range(palette);
  }

  function thresholdLabel(index, thresholds) {
    const lower = index === 0 ? 0 : thresholds[index - 1];
    if (index === 0) return `>0 – <${formatNumber(thresholds[0])}`;
    if (index >= thresholds.length) return `${formatNumber(thresholds[index - 1])}+`;
    const upper = thresholds[index];
    return `${formatNumber(lower)} – <${formatNumber(upper)}`;
  }
  // [/lesson:color]

  // [lesson:connect]
  function drawNeighborhoods(options) {
    const {
      layer,
      features,
      stats,
      path,
      color,
      selectedName = null,
      interactive = true,
      onHover,
      onLeave,
      onSelect,
    } = options;

    const shapes = layer
      .selectAll('path.neighborhood')
      .data(features, (d) => d.properties.name)
      .join('path')
      .attr('class', 'neighborhood')
      .attr('fill', (d) => {
        const entry = stats.get(d.properties.name);
        return !entry ? '#c8bfae' : entry.records === 0 ? '#e6e4de' : color(entry.density);
      })
      .attr('d', path)
      .classed('is-selected', (d) => d.properties.name === selectedName)
      .attr('tabindex', interactive ? 0 : null)
      .attr('role', interactive ? 'button' : null)
      .attr('aria-pressed', interactive
        ? (d) => String(d.properties.name === selectedName)
        : null)
      .attr('aria-label', interactive
        ? (d) => {
            const entry = stats.get(d.properties.name);
            return `${d.properties.name}: ${formatNumber(entry.records)} records, ${formatNumber(entry.works)} titles, ${formatNumber(entry.density, 1)} records per square kilometre.`;
          }
        : null);

    if (interactive) {
      shapes
        .on('pointerenter', (event, d) => onHover && onHover(event, d))
        .on('pointermove', (event, d) => onHover && onHover(event, d))
        .on('pointerleave', (event, d) => onLeave && onLeave(event, d))
        .on('focus', (event, d) => onHover && onHover(event, d, true))
        .on('blur', (event, d) => onLeave && onLeave(event, d))
        .on('click', (event, d) => {
          event.stopPropagation();
          onSelect && onSelect(d.properties.name);
        })
        .on('keydown', (event, d) => {
          if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            onSelect && onSelect(d.properties.name);
          }
        });
    }
    return shapes;
  }
  // [/lesson:connect]

  function formatNumber(value, digits = 0) {
    if (value === null || value === undefined || Number.isNaN(Number(value))) return '—';
    return new Intl.NumberFormat('en-US', {
      minimumFractionDigits: digits,
      maximumFractionDigits: digits,
    }).format(Number(value));
  }

  function formatRange(range) {
    if (!range || range.key === 'all') return 'All years';
    return `${range.start}–${range.end}`;
  }

  function formatCoords(lon, lat) {
    if (lon === null || lat === null) return 'No coordinates';
    return `${Number(lat).toFixed(5)}, ${Number(lon).toFixed(5)}`;
  }

  function escapeHTML(value) {
    return String(value ?? '')
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
  }

  function groupLocations(records) {
    const groups = new Map();
    const unmapped = [];
    for (const record of records) {
      if (record.pointMapped) {
        const key = `${record.lon.toFixed(5)},${record.lat.toFixed(5)}`;
        if (!groups.has(key)) {
          groups.set(key, {
            key,
            lon: record.lon,
            lat: record.lat,
            records: [],
            mapped: true,
          });
        }
        groups.get(key).records.push(record);
      } else {
        unmapped.push(record);
      }
    }
    return {
      mapped: [...groups.values()],
      unmapped,
    };
  }

  global.AtlasCore = {
    filterRecords,
    aggregate,
    makeProjection,
    makeColorScale,
    thresholdLabel,
    drawNeighborhoods,
    formatNumber,
    formatRange,
    formatCoords,
    escapeHTML,
    groupLocations,
    DENSITY_FALLBACK,
  };
})(window);
