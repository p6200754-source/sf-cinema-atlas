import {prepareRecords,orientFeature} from './data.js';

// TASK 1: edit these five colors, light to dark, then save.
// HEX, rgb(), rgba(), hsl(), or a D3 palette such as d3.schemeOranges[5] work.
const palette = ['#edf0e6','#cedbc9','#9dbbab','#6b958d','#376866'];

// TASK 2: null = all years; 2019 = the year 2019.
const YEAR = null;
// 'exact' = this year only; 'since' = this year and later.
const YEAR_MODE = 'exact';

// Read the local original CSV, filter, aggregate and draw.
const C=window.AtlasCore;
try{
 const [rows,areas,tracts,streets]=await Promise.all([
  d3.csv('data/film_locations.csv'),d3.json('data/neighborhoods.geojson'),
  d3.json('data/tracts.geojson'),d3.json('data/streets.geojson')
 ]);
 const features=areas.features.map(orientFeature);
 features.forEach(f=>f.properties.areaKm2=f.properties.area_km2);
 tracts.features=tracts.features.map(orientFeature);
 const prepared=prepareRecords(rows,features,tracts);
 const range=YEAR===null?{key:'all'}:{start:YEAR,end:YEAR_MODE==='since'?Infinity:YEAR};
 const filtered=C.filterRecords(prepared.records,range);
 const stats=C.aggregate(filtered,features),thresholds=[3,12,35,90];
 const svg=d3.select('#map'),color=C.makeColorScale(thresholds,palette);
 const width=900,height=650;
 svg.attr('viewBox',`0 0 ${width} ${height}`);
 const {path}=C.makeProjection(features,width,height,24),layer=svg.append('g');
 C.drawNeighborhoods({layer,features,stats,path,color,interactive:false});
 layer.append('path').datum(streets).attr('d',path).attr('fill','none').attr('stroke','#f4efe5').attr('stroke-width',.7);
 layer.selectAll('.neighborhood').append('title').text(f=>{const s=stats.get(f.properties.name);return `${f.properties.name}: ${s.records} records; ${s.works} titles; ${s.density.toFixed(1)} records / km²`;});
 svg.call(d3.zoom().scaleExtent([1,7]).on('zoom',e=>layer.attr('transform',e.transform)));
 d3.select('#legend').selectAll('div').data(palette).join('div').each(function(c,i){
  d3.select(this).append('span').style('background',c);
  d3.select(this).append('small').text(C.thresholdLabel(i,thresholds));
 });
 const assigned=[...stats.values()].reduce((sum,s)=>sum+s.records,0);
 const label=YEAR===null?'All years':YEAR_MODE==='since'?`${YEAR} onward`:String(YEAR);
 document.querySelector('#summary').textContent=`${label} · ${assigned.toLocaleString()} of ${filtered.length.toLocaleString()} records assigned · ${(filtered.length-assigned).toLocaleString()} unassigned. Area includes mapped water.`;
 document.querySelector('#audit').textContent=`Your CSV: ${prepared.rawRows.toLocaleString()} rows; ${prepared.duplicates} all-column duplicates removed; ${prepared.spatialFills} missing neighborhood assignments filled from valid points. Newer exports may differ from the website snapshot.`;
}catch(error){document.querySelector('#summary').textContent='Could not draw the map: '+error.message;console.error(error);}
