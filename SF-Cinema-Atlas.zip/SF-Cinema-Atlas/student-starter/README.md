# SF Cinema Atlas - VS Code exercise / 本地练习

1. Unzip the whole project and open its folder in VS Code. / 解压整个项目，用 VS Code 打开文件夹。
2. Use the VS Code Live Server extension to open index.html (right-click > Open with Live Server). Do not double-click with file://: CSV and modules need a local HTTP server. Installing the extension requires internet. / 使用 Live Server 启动；不能直接双击打开。
3. In map.js, edit the existing palette, YEAR and YEAR_MODE values near the top. Save and refresh the browser (Live Server usually refreshes automatically). Do not add duplicate const declarations. / 修改已有值，不要重复声明。
4. Task 1: change the five palette colors to custom HEX/RGB/HSL values, or replace the array with d3.schemeOranges[5]. Keep a light-to-dark order. Record counts should stay the same.
5. Task 2: YEAR=null shows all years. YEAR=2019 and YEAR_MODE='exact' shows only 2019. YEAR=2010 and YEAR_MODE='since' shows 2010 onward. This filters release year, not filming year.
6. Save a screenshot and edited map.js according to your instructor's submission channel. The website does not collect or submit your work.

## Original CSV / 官方原始数据

Dataset: https://data.sfgov.org/Culture-and-Recreation/Film-Locations-in-San-Francisco/yitu-d5am/about_data

CSV: https://data.sfgov.org/api/views/yitu-d5am/rows.csv?accessType=DOWNLOAD

Export the complete unfiltered CSV. Rename it film_locations.csv and replace data/film_locations.csv. Keep the source column names. The starter already includes the unmodified full official CSV downloaded on 2026-10-24, so a new download is optional. A newer export can differ from the fixed website snapshot.

从官方页面导出完整、未筛选的 CSV，命名为 film_locations.csv，替换 data 文件夹中同名文件。不要修改列名。练习包已包含2026-10-24下载的完整原始 CSV；新下载的数据如果更新了，记录数可能与网站快照不同。

The map reads this actual CSV on every load. No invented/sample rows or hardcoded totals are used. Only all-column exact duplicates are removed. Valid source neighborhoods are preserved; missing assignments are filled only when a valid point identifies one supplied neighborhood. Fills are flagged; unresolved records remain unassigned. Original rows are retained in sourceRow. All years includes unknown-year rows; year filters exclude them.

## Geography and licenses / 地理资料与许可

Boundaries: https://data.sfgov.org/Geographic-Locations-and-Boundaries/Analysis-Neighborhoods-2020-census-tracts-assigned/sevw-6tgi/about_data

The 41 mapped neighborhoods are derived from 2020 census tracts assigned to neighborhoods, excluding The Farallones. tracts.geojson supplies the unsimplified source tracts for spatial matching. neighborhoods.geojson is simplified for drawing; its precomputed WGS84 geodesic area includes mapped water. Simplification does not change the denominator.

Roads: https://www2.census.gov/geo/tiger/TIGER2024/ROADS/tl_2024_06075_roads.zip

Street texture is contextual, not historical reconstruction. Fixed density thresholds: 3, 12, 35, 90; zero is separate. D3 is bundled locally: see vendor/d3.LICENSE. The full website ZIP contains preparation scripts, source audit and other licenses. AtlasCore supplies the same filter, aggregation, projection and color logic as the website. No API key or npm installation is needed.
