// Only all-column exact duplicate rows are removed. Original rows are retained.
export function prepareRecords(rows,features,tracts){
 const clean=v=>String(v??'').replace(/\u00a0/g,' ').replace(/\s+/g,' ').trim();
 for(const k of ['Title','Release Year','Analysis Neighborhood','Longitude','Latitude'])if(!rows.columns.includes(k))throw Error(`Missing CSV column: ${k}. Download the complete original DataSF CSV.`);
 const names=new Set(features.map(f=>f.properties.name)),seen=new Set(),records=[];
 let duplicates=0,spatialFills=0;
 for(const row of rows){
  const signature=JSON.stringify(rows.columns.map(k=>row[k]));
  if(seen.has(signature)){duplicates++;continue;}seen.add(signature);
  const title=clean(row.Title),t=clean(row['Release Year']),y=/^\d{4}$/.test(t)?Number(t):null;
  const year=y!==null&&y>=1880&&y<=new Date().getFullYear()+1?y:null;
  let neighborhood=clean(row['Analysis Neighborhood']),source='field';
  if(!names.has(neighborhood)){
   neighborhood=null;source='unassigned';
   const lo=clean(row.Longitude),la=clean(row.Latitude),lon=Number(lo),lat=Number(la);
   if(lo&&la&&Number.isFinite(lon)&&Number.isFinite(lat)&&lon>=-123.1&&lon<=-121.9&&lat>=37.3&&lat<=38.2){
    const hits=new Set(tracts.features.filter(f=>names.has(clean(f.properties.neighborhoods_analysis_boundaries))&&d3.geoContains(f,[lon,lat])).map(f=>clean(f.properties.neighborhoods_analysis_boundaries)));
    if(hits.size===1){neighborhood=[...hits][0];source='spatial';spatialFills++;}
   }
  }
  records.push({id:records.length+1,title,year,neighborhood,neighborhoodSource:source,workKey:title.toLowerCase()+'|'+(year??'unknown'),pointMapped:false,sourceRow:row});
 }
 return {records,rawRows:rows.length,duplicates,spatialFills};
}
export function orientFeature(feature){
 const f=structuredClone(feature);
 if(d3.geoArea(f)>2*Math.PI){
  if(f.geometry.type==='Polygon')f.geometry.coordinates.forEach(r=>r.reverse());
  if(f.geometry.type==='MultiPolygon')f.geometry.coordinates.forEach(p=>p.forEach(r=>r.reverse()));
 }
 return f;
}
