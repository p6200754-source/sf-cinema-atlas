# SF Cinema Atlas

A buildless D3 v7 teaching site for SM6351: explore real San Francisco film-location records, understand four code ideas, and manually edit two small tasks.

## Open locally

From this directory:

```sh
python3 -m http.server 8765 --bind 127.0.0.1
```

Open http://127.0.0.1:8765 in a browser. If you serve the parent workspace instead, open `/cinema-atlas/`. Do not double-click index.html: browser modules and local data need HTTP. No npm install, account or API key is needed. D3, fonts and data are bundled. Internet is needed only for visiting source links or refreshing snapshots.

## Site structure

- Explore: real neighborhood choropleth, street texture, release-year filters, keyboard or pointer selection, searchable title lists, location archive and local map.
- Behind the map: four excerpts extracted from the actual shared map core.
- Your turn: isolated editable JavaScript, Run, Reset task, hints, code location, export and per-task browser-local edits.
- About the data: coverage, source links and explicit calculation rules.

Task 1 changes the five-color palette (HEX, RGB, RGBA, HSL or D3); the default matches Explore. Task 2 edits YEAR and YEAR_MODE: null shows all, 2019 with "exact" shows only 2019, and 2000 with "since" shows 2000 onward. One fully editable map.js uses the shared homepage map core. Task goals are examples, not execution restrictions. Reset restores the current task; Run previews the edited code; Export saves map.js for the supplied host. Older drafts remain in the previous browser-storage key.

## Evidence and data integrity

`data/raw/film_locations_raw.csv` is the unmodified official CSV. It was downloaded and byte-compared with the official full export on 2026-10-24. SHA256:

`6607f7d1ce2bf4acc71ea4ae697cf3566b1bfb5dc729e657465f219d9e90daad`

It contains 2,214 rows. Six rows identical across **all** source columns are removed in derived files, leaving 2,208 records and 352 normalized title–year keys. The original remains intact. No rows are removed merely because title or location repeats. Source text is whitespace-normalized for display; raw text stays in the CSV. No external film photographs, posters, ratings, genres, synopses or person data are used.

Geography is auxiliary, separate from film metadata:

1. DataSF `yitu-d5am`: film records. https://data.sf.gov/api/v3/views/yitu-d5am/export.csv?accessType=DOWNLOAD
2. DataSF `sevw-6tgi`: 2020 census tracts assigned to analysis neighborhoods; dissolved into 41 in-city neighborhoods. Offshore The Farallones is outside the displayed study area.
3. U.S. Census Bureau TIGER/Line 2024 San Francisco County road centerlines: context only. https://www2.census.gov/geo/tiger/TIGER2024/ROADS/tl_2024_06075_roads.zip

Geodesic area uses WGS84 on full dissolved polygons, includes mapped water, and is **not land-only area**. Drawing uses simplified geography. DataSF's supplied neighborhood field remains the primary aggregation key. Eight missing assignments are filled from valid points and explicitly flagged. Unassigned records do not color a neighborhood. Points with conflicts or outside the study area are not moved; they are suppressed while field-assigned counts remain. See `data/processed/audit.json` and the About page for computed counts.

Location markers group coordinates rounded to five decimal places for coincident-location display. Dots stay at their supplied coordinates. Numbered labels appear only when a location is hovered, focused or selected; the full numbered index remains in the archive. There are no displacement leaders or permanent badge clouds. All linked record IDs and descriptions remain accessible. This is not a route or historical reconstruction. Minor cartographic boundary simplification can affect edge appearance.

Density is assigned records divided by neighborhood area. Thresholds [3,12,35,90] are fixed rounded breaks chosen after inspecting the long-tailed full-snapshot distribution, not quantiles or an inference about film success. Zero has a separate grey key. All years includes one unknown-year record; other ranges and the exercise exclude it. Release year is never presented as shooting year.

## Verify or rebuild

Standard library source-to-display check:

```sh
python3 scripts/verify_data.py
```

This checks every retained record against its source text, actor fields, coordinates, original area when supplied, and all 41 aggregate counts/densities. It writes `docs/source-verification.json`.

The saved raw inputs are sufficient to reproduce processed data. Data preparation requires Python packages in `scripts/requirements.txt`:

```sh
python3 -m venv .venv
.venv/bin/pip install -r scripts/requirements.txt
.venv/bin/python scripts/process_data.py
python3 scripts/verify_data.py
```

`process_data.py` only transforms the saved raw inputs. It does not silently update the snapshot. If intentionally updating data, download complete official exports, retain source provenance and checksums, update snapshot date in the preparation script, rerun processing and recheck all statistics. Never overwrite a snapshot just to match a concept illustration.

## GitHub Pages

Upload the contents of this folder as the site root or a repository subfolder. Relative paths and hash navigation work under a repository prefix. This version has not been published and does not contain GitHub credentials. Enable Pages separately when ready. The downloadable ZIP contains source, raw/processed data, local libraries/fonts, preparation scripts, usage documents and real browser screenshots. After extracting the ZIP, run `python3 scripts/package_project.py` if you want to regenerate the website’s project-download button; the ZIP intentionally does not recursively include itself.

## Classroom materials

- `docs/presentation-outline.md`: suggested presentation sequence and live walkthrough.
- `docs/QA.md`: checks performed and known limitations.
- `screenshots/`: actual running pages, not generated concept images.
- Team member names and final slide deck are intentionally left for the group.

## Layout and interaction approach

No overlapping decorative 3D layers. Content uses grid/flex with `minmax(0,1fr)` and wrapping; the archive scrolls independently on desktop and stacks naturally on phones. Long titles wrap. The map fits the complete in-city scope, including islands, without invented positions. Focus map zooms to the selected neighborhood; Return to full city restores extent. Wheel scrolling is not hijacked.

The practice iframe has an opaque origin, no network access, no forms/popups and no same-origin permission. Syntax and runtime errors are reported outside it. This is a recoverable classroom runner, not a security boundary for arbitrary hostile code or infinite loops; Reset / Rebuild are provided and a nonresponding runner is reported.

## Licenses

DataSF's catalog lists PDDL 1.0 for the film dataset. City/census geography is attributed by source; no external movie image license is assumed. D3's ISC license is in `vendor/d3.LICENSE`; font OFL licenses are alongside fonts. Keep all bundled licenses and source attribution when redistributing.

## 2026-10-25 visual and classroom update

The atlas now uses a pale-sage to dark-teal sequential scale, with copper reserved for accents. The archive has ticket perforations and a typographic stub. Behind the map defaults to short code excerpts and speaking notes. Explicit before/after task instructions are in `docs/revision-2026-10-25.md`. Statistics and data files are unchanged.
