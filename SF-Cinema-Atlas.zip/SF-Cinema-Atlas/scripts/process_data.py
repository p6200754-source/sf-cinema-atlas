#!/usr/bin/env python3
"""Build the SF Cinema Atlas data products from official source snapshots.

Inputs (already downloaded, see scripts/fetch_data.sh):
  data/raw/film_locations_raw.csv             DataSF yitu-d5am full CSV
  data/raw/neighborhood_tracts_2020.geojson   DataSF sevw-6tgi 2020 tracts
  data/raw/tl_2024_06075_roads.zip            Census TIGER 2024 roads

Outputs:
  data/processed/neighborhoods.geojson
  data/processed/streets.geojson
  data/processed/atlas.json
  data/processed/audit.json

All numbers in the website and audit are computed from these inputs.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import math
import re
import statistics
import sys
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

import shapefile  # pyshp
from pyproj import Geod
from shapely.geometry import LineString, MultiLineString, Point, Polygon, shape, mapping
from shapely.ops import unary_union
from shapely.validation import make_valid
from shapely.prepared import prep

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw"
OUT = ROOT / "data" / "processed"
OUT.mkdir(parents=True, exist_ok=True)

FILM_CSV = RAW / "film_locations_raw.csv"
TRACT_GEOJSON = RAW / "neighborhood_tracts_2020.geojson"
ROADS_ZIP = RAW / "tl_2024_06075_roads.zip"

SNAPSHOT_DATE = dt.date(2026, 10, 24)
SOURCE_URL = "https://data.sfgov.org/Culture-and-Recreation/Film-Locations-in-San-Francisco/yitu-d5am/about_data"
BOUNDARY_URL = "https://data.sfgov.org/Geographic-Locations-and-Boundaries/Analysis-Neighborhoods-2020-census-tracts-assigned/sevw-6tgi/about_data"
ROADS_URL = "https://www2.census.gov/geo/tiger/TIGER2024/ROADS/tl_2024_06075_roads.zip"

# The offshore Farallon tract is part of the census-derived file but outside the
# mapped city and outside the film dataset's 40 populated analysis neighborhoods.
EXCLUDED_AREAS = {"The Farallones"}


def clean_text(value: str | None) -> str:
    if value is None:
        return ""
    return re.sub(r"\s+", " ", value.replace("\xa0", " ")).strip()


def norm_title(value: str) -> str:
    # Case/whitespace normalisation for grouping only; display keeps original title.
    return clean_text(value).casefold()


def fmt_num(n: float, digits: int = 1) -> str:
    return f"{n:,.{digits}f}"


def geodesic_area_km2(geom) -> float:
    geod = Geod(ellps="WGS84")
    total = 0.0
    geoms = list(geom.geoms) if geom.geom_type == "MultiPolygon" else [geom]
    for poly in geoms:
        if poly.is_empty:
            continue
        outer = list(poly.exterior.coords)
        area, _ = geod.geometry_area_perimeter(__import__("shapely").geometry.Polygon(outer))
        a = abs(area)
        for ring in poly.interiors:
            hole, _ = geod.geometry_area_perimeter(__import__("shapely").geometry.Polygon(list(ring.coords)))
            a -= abs(hole)
        total += a
    return total / 1_000_000


def round_coords(obj, ndigits=5):
    if isinstance(obj, float):
        return round(obj, ndigits)
    if isinstance(obj, list):
        return [round_coords(v, ndigits) for v in obj]
    if isinstance(obj, tuple):
        return [round_coords(v, ndigits) for v in obj]
    if isinstance(obj, dict):
        return {k: round_coords(v, ndigits) for k, v in obj.items()}
    return obj


def load_tracts():
    data = json.loads(TRACT_GEOJSON.read_text())
    groups = defaultdict(list)
    for feature in data["features"]:
        name = clean_text(feature["properties"].get("neighborhoods_analysis_boundaries", ""))
        if not name or name in EXCLUDED_AREAS:
            continue
        geom = shape(feature["geometry"])
        if not geom.is_valid:
            geom = geom.buffer(0)
        groups[name].append(geom)
    return groups


def dissolve_neighborhoods():
    groups = load_tracts()
    features = []
    full_shapes = {}
    area_by_name = {}
    for name, pieces in sorted(groups.items()):
        geom = unary_union(pieces)
        if geom.is_empty:
            continue
        # Remove tiny slivers introduced by tract joins.
        geom = geom.buffer(0)
        if not geom.is_valid:
            geom = make_valid(geom)
        area = geodesic_area_km2(geom)
        full_shapes[name] = geom
        area_by_name[name] = round(area, 4)
        simple = geom.simplify(0.000065, preserve_topology=True)
        simple_area = geodesic_area_km2(simple)
        label_point = geom.representative_point()
        label_point = geom.representative_point()
        features.append({
            "type": "Feature",
            "properties": {
                "name": name,
                "area_km2": round(area, 4),
                "area_simplified_km2": round(simple_area, 4),
                "label_lon": round(label_point.x, 6),
                "label_lat": round(label_point.y, 6),
            },
            "geometry": round_coords(mapping(simple), 5),
        })
    features.sort(key=lambda f: f["properties"]["name"])
    geo = {
        "type": "FeatureCollection",
        "name": "analysis_neighborhoods",
        "crs": {"type": "name", "properties": {"name": "urn:ogc:def:crs:OGC:1.3:CRS84"}},
        "features": features,
    }
    return geo, full_shapes, area_by_name


def load_film_rows():
    with FILM_CSV.open(encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def dedupe(rows):
    seen = set()
    kept = []
    duplicates = []
    for r in rows:
        key = tuple((k, r[k]) for k in r.keys())
        if key in seen:
            duplicates.append(r)
        else:
            seen.add(key)
            kept.append(r)
    return kept, duplicates


def main():
    if not (FILM_CSV.exists() and TRACT_GEOJSON.exists() and ROADS_ZIP.exists()):
        sys.exit("Missing source snapshots; run scripts/fetch_data.sh first.")

    geo, shapes, area_by_name = dissolve_neighborhoods()
    names = sorted(shapes)
    # Shapely's bulk union can trip on the shared, high-vertex tract edges in
    # this census product; incremental union is equivalent and stable.
    union = None
    for name in names:
        geom = shapes[name]
        union = geom if union is None else union.union(geom)
    if not union.is_valid:
        union = union.buffer(0)
    prepared = prep(union)

    raw_rows = load_film_rows()
    rows, exact_dupes = dedupe(raw_rows)

    # Keep a stable internal row id based on source order after dedupe.
    records = []
    missing_year = 0
    invalid_year_values = []
    missing_location = 0
    missing_coords_raw = 0
    outside_coords = 0
    field_missing = 0
    spatial_filled = 0
    unassigned = 0
    field_geom_conflict = 0
    field_and_outside = 0
    point_mapped = 0
    point_outside_or_unmatched = 0
    field_counts = Counter()
    spatial_counts = Counter()
    missing_nbhd_with_coords = 0
    missing_nbhd_filled = 0
    title_year_counts = Counter()
    exact_title_counts = Counter()

    for idx, r in enumerate(rows, start=1):
        title = clean_text(r.get("Title", ""))
        year_raw = clean_text(r.get("Release Year", ""))
        year = None
        if year_raw:
            if re.fullmatch(r"\d{4}", year_raw):
                year = int(year_raw)
                if not (1880 <= year <= SNAPSHOT_DATE.year + 1):
                    invalid_year_values.append((title, year_raw))
                    year = None
            else:
                invalid_year_values.append((title, year_raw))
        if year is None:
            missing_year += 1

        lon_raw = clean_text(r.get("Longitude", ""))
        lat_raw = clean_text(r.get("Latitude", ""))
        lon = lat = None
        coords_valid = False
        if lon_raw and lat_raw:
            try:
                lon = float(lon_raw)
                lat = float(lat_raw)
                coords_valid = (
                    math.isfinite(lon) and math.isfinite(lat)
                    and -180 <= lon <= 180 and -90 <= lat <= 90
                    and -123.1 <= lon <= -121.9 and 37.3 <= lat <= 38.2
                )
            except ValueError:
                coords_valid = False
        else:
            missing_coords_raw += 1
        if lon_raw and lat_raw and not coords_valid:
            outside_coords += 1

        field_nbhd = clean_text(r.get("Analysis Neighborhood", ""))
        if field_nbhd and field_nbhd not in shapes:
            field_nbhd = ""
        if not field_nbhd:
            field_missing += 1
            if coords_valid:
                missing_nbhd_with_coords += 1

        containing = ""
        in_city = False
        if coords_valid:
            p = Point(lon, lat)
            if prepared.contains(p):
                in_city = True
                for n, s in shapes.items():
                    if s.contains(p):
                        containing = n
                        break

        source = "unassigned"
        neighborhood = field_nbhd
        if field_nbhd:
            source = "field"
            field_counts[field_nbhd] += 1
            if coords_valid and not in_city:
                field_and_outside += 1
            elif coords_valid and in_city and containing and containing != field_nbhd:
                field_geom_conflict += 1
        elif containing:
            neighborhood = containing
            source = "spatial"
            spatial_filled += 1
            missing_nbhd_filled += 1
            spatial_counts[containing] += 1
        else:
            source = "unassigned"
            unassigned += 1

        # A point is drawn only when it falls inside the very neighborhood used
        # for the statistic. Field/point disagreements stay in the density but
        # are not placed on the map; this avoids moving or visually misassigning
        # a source coordinate.
        point_mapped_flag = bool(coords_valid and in_city and neighborhood and containing == neighborhood)
        if point_mapped_flag:
            point_mapped += 1
        elif coords_valid:
            point_outside_or_unmatched += 1

        work_key = f"{norm_title(title)}|{year if year is not None else 'unknown'}"
        title_year_counts[work_key] += 1
        exact_title_counts[title] += 1

        location = clean_text(r.get("Locations", ""))
        if not location:
            missing_location += 1
        actors = [clean_text(r.get(f"Actor {i}", "")) for i in (1, 2, 3)]
        actors = [a for a in actors if a]

        records.append({
            "id": idx,
            "title": title,
            "year": year,
            "yearRaw": year_raw,
            "workKey": work_key,
            "locations": location,
            "funFacts": clean_text(r.get("Fun Facts", "")),
            "productionCompany": clean_text(r.get("Production Company", "")),
            "distributor": clean_text(r.get("Distributor", "")),
            "director": clean_text(r.get("Director", "")),
            "writer": clean_text(r.get("Writer", "")),
            "actors": actors,
            "lon": round(lon, 7) if coords_valid else None,
            "lat": round(lat, 7) if coords_valid else None,
            "coordsValid": coords_valid,
            "inCity": in_city,
            "pointMapped": point_mapped_flag,
            "neighborhood": neighborhood,
            "neighborhoodSource": source,
            "spatialNeighborhood": containing or None,
            "supervisorDistrict": clean_text(r.get("Supervisor District", "")),
            "dataAsOf": clean_text(r.get("data_as_of", "")),
            "dataLoadedAt": clean_text(r.get("data_loaded_at", "")),
        })

    # Aggregate the full snapshot (all years, including records with unknown year).
    agg = {n: {"records": 0, "works": set(), "pointRecords": 0} for n in names}
    year_counts = Counter()
    for rec in records:
        n = rec["neighborhood"]
        if not n:
            continue
        agg[n]["records"] += 1
        agg[n]["works"].add(rec["workKey"])
        if rec["pointMapped"]:
            agg[n]["pointRecords"] += 1
        if rec["year"] is not None:
            year_counts[rec["year"]] += 1

    neighborhoods = []
    for n in names:
        count = agg[n]["records"]
        density = count / area_by_name[n] if area_by_name[n] else None
        neighborhoods.append({
            "name": n,
            "records": count,
            "works": len(agg[n]["works"]),
            "pointRecords": agg[n]["pointRecords"],
            "areaKm2": area_by_name[n],
            "density": round(density, 4) if density is not None else None,
        })

    densities = sorted(x["density"] for x in neighborhoods if x["density"] is not None)
    # Fixed, nice-number thresholds chosen from the full-snapshot distribution.
    # Quantile anchors are recorded so the decision can be audited.
    quantile_anchors = {
        f"p{q}": round(densities[min(len(densities)-1, max(0, math.ceil(q/100*len(densities))-1))], 3)
        for q in (20, 40, 60, 80)
    }
    thresholds = [3, 12, 35, 90]
    # Ensure the chosen thresholds are monotone and cover the observed maximum.
    assert all(thresholds[i] < thresholds[i+1] for i in range(len(thresholds)-1))
    assert densities[-1] > thresholds[-1], (densities[-1], thresholds)

    all_years = sorted(year_counts)
    year_min, year_max = all_years[0], all_years[-1]
    total_works = len({r["workKey"] for r in records})
    total_titles = len({r["title"] for r in records})
    total_records = len(records)
    assigned = sum(1 for r in records if r["neighborhood"])
    mapped = sum(1 for r in records if r["pointMapped"])
    missing_coords = sum(1 for r in records if not r["coordsValid"])
    missing_nbhd = sum(1 for r in records if not r["neighborhood"])

    # Distinct raw data_as_of values should all be the same snapshot date.
    asof_values = sorted({r["dataAsOf"] for r in records if r["dataAsOf"]})

    # Road texture: TIGER/Line 2024, clipped to the mapped city, simplified.
    with zipfile.ZipFile(ROADS_ZIP) as zf:
        zf.extractall(RAW / "tiger_roads")
    shp = shapefile.Reader(str(RAW / "tiger_roads" / "tl_2024_06075_roads"))
    road_features = []
    road_total = 0
    for sr in shp.iterShapeRecords():
        geom = shape(sr.shape.__geo_interface__)
        if not geom.intersects(union):
            continue
        clipped = geom.intersection(union)
        if clipped.is_empty:
            continue
        clipped = clipped.simplify(0.000025, preserve_topology=False)
        if clipped.is_empty:
            continue
        mtfcc = sr.record["MTFCC"]
        road_class = "major" if mtfcc in {"S1100", "S1200"} else "local"
        geoms = list(clipped.geoms) if clipped.geom_type.startswith("Multi") else [clipped]
        for g in geoms:
            if g.geom_type != "LineString" or len(g.coords) < 2:
                continue
            road_features.append({
                "type": "Feature",
                "properties": {"class": road_class},
                "geometry": round_coords(mapping(g), 5),
            })
            road_total += 1
    streets = {"type": "FeatureCollection", "name": "sf_road_centerlines", "features": road_features}

    # Boundary for coastline stroke only.
    outline_simple = union.simplify(0.00008, preserve_topology=True)

    meta = {
        "title": "SF Cinema Atlas",
        "generatedAt": SNAPSHOT_DATE.isoformat(),
        "source": {
            "name": "Film Locations in San Francisco",
            "publisher": "DataSF / City and County of San Francisco",
            "resourceId": "yitu-d5am",
            "url": SOURCE_URL,
            "rawFile": "data/raw/film_locations_raw.csv",
            "downloadDate": SNAPSHOT_DATE.isoformat(),
            "dataAsOf": asof_values,
        },
        "geography": {
            "name": "Analysis Neighborhoods (2020 census tracts assigned to neighborhoods)",
            "resourceId": "sevw-6tgi",
            "url": BOUNDARY_URL,
            "rawFile": "data/raw/neighborhood_tracts_2020.geojson",
            "downloadDate": SNAPSHOT_DATE.isoformat(),
            "areaMethod": "Geodesic area on WGS84 (pyproj Geod), computed on the dissolved 2020-tract neighborhood polygons; includes any mapped water inside the boundary, not a land-only area.",
            "simplification": "Topology-preserving simplification, tolerance 0.000065 degrees, used for drawing only; densities use the unsimplified geodesic area.",
            "excludedAreas": sorted(EXCLUDED_AREAS),
            "includedNeighborhoods": len(names),
        },
        "streets": {
            "name": "TIGER/Line 2024 Roads, San Francisco County",
            "publisher": "U.S. Census Bureau",
            "url": ROADS_URL,
            "downloadDate": SNAPSHOT_DATE.isoformat(),
            "note": "Auxiliary road-centerline texture only; not a historical street map.",
            "features": road_total,
        },
        "d3Version": "7.9.0",
        "rawRows": len(raw_rows),
        "exactDuplicateRowsRemoved": len(exact_dupes),
        "rowsUsed": total_records,
        "titles": total_titles,
        "works": total_works,
        "yearMin": year_min,
        "yearMax": year_max,
        "missingYearRecords": missing_year,
        "invalidYearValues": invalid_year_values,
        "missingLocationRecords": missing_location,
        "missingCoordinateRecords": missing_coords,
        "recordsWithNeighborhood": assigned,
        "recordsWithoutNeighborhood": missing_nbhd,
        "recordsMappedInsideCity": mapped,
        "recordsNotMapped": total_records - mapped,
        "spatialNeighborhoodFills": spatial_filled,
        "fieldNeighborhoodCounts": dict(field_counts),
        "spatialFillCounts": dict(spatial_counts),
        "outsideOrInvalidCoordinates": outside_coords,
        "fieldAssignedButPointOutsideCity": field_and_outside,
        "pointInDifferentNeighborhoodThanField": field_geom_conflict,
        "unassignedRecords": unassigned,
        "thresholds": thresholds,
        "thresholdMethod": "Five fixed classes using rounded, manually reviewed boundaries anchored against the full-snapshot density quantiles; classes are shared by every year filter.",
        "quantileAnchors": quantile_anchors,
        "densityMin": round(densities[0], 3),
        "densityMedian": round(statistics.median(densities), 3),
        "densityMax": round(densities[-1], 3),
        "workKeyRule": "Normalised title (trimmed, whitespace-collapsed, case-folded) + release year; missing year becomes the literal 'unknown'. Records with the same title and year are treated as one work, not one shooting event.",
        "timeRule": "Filters use release year, not shooting year. All years includes records with an unknown release year. Any other range excludes records without a usable year.",
        "coverageRule": "Records without a usable neighborhood are excluded from neighborhood density. A missing neighborhood is filled from a valid point only when the point falls inside exactly one of the 41 included neighborhood polygons; the fill is flagged. A point is drawn only when it lies inside the neighborhood used for the statistic. Points outside the city, or in a different neighborhood than the source field, remain in the density under the field but are not placed on the map.",
        "exactDuplicateRule": "Only rows identical across every source column were removed; no records were removed because they share a title, year, or location.",
        "areaTotalKm2": round(sum(area_by_name.values()), 3),
        "neighborhoodsWithZeroRecords": [n for n in names if agg[n]["records"] == 0],
    }

    atlas = {
        "meta": meta,
        "neighborhoods": neighborhoods,
        "years": [{"year": y, "records": year_counts[y]} for y in all_years],
        "records": records,
    }

    # Write geodata; include a coastline outline.
    geo_out = dict(geo)
    geo_out["outline"] = round_coords(mapping(outline_simple), 5)
    (OUT / "neighborhoods.geojson").write_text(
        json.dumps(geo_out, ensure_ascii=False, separators=(",", ":")), encoding="utf-8"
    )
    (OUT / "streets.geojson").write_text(
        json.dumps(streets, ensure_ascii=False, separators=(",", ":")), encoding="utf-8"
    )
    (OUT / "atlas.json").write_text(
        json.dumps(atlas, ensure_ascii=False, separators=(",", ":")), encoding="utf-8"
    )

    # Audit deliverable with reproducible numbers and spot checks.
    spot_names = ["North Beach", "Mission", "Sunset/Parkside", "Visitacion Valley"]
    spot = {}
    for n in spot_names:
        recs = [r for r in records if r["neighborhood"] == n]
        spot[n] = {
            "records": len(recs),
            "works": len({r["workKey"] for r in recs}),
            "areaKm2": area_by_name[n],
            "density": round(len(recs) / area_by_name[n], 4) if area_by_name[n] else None,
            "pointRecords": sum(1 for r in recs if r["pointMapped"]),
        }
    audit = {
        "generatedAt": meta["generatedAt"],
        "sourceChecks": {
            "filmCsvRowsIncludingHeader": len(raw_rows) + 1,
            "filmDataRows": len(raw_rows),
            "exactDuplicateRows": len(exact_dupes),
            "exactDuplicateExamples": [
                {"title": clean_text(r["Title"]), "year": clean_text(r["Release Year"]), "location": clean_text(r["Locations"])}
                for r in exact_dupes[:6]
            ],
            "boundaryTractFeatures": 242,
            "neighborhoodsIncluded": len(names),
            "neighborhoodsExcluded": sorted(EXCLUDED_AREAS),
            "roadFeaturesInTexture": road_total,
            "downloadDate": SNAPSHOT_DATE.isoformat(),
            "dataAsOf": asof_values,
        },
        "coverage": {
            "recordsUsed": total_records,
            "works": total_works,
            "titles": total_titles,
            "releaseYearRange": [year_min, year_max],
            "missingYear": missing_year,
            "missingCoordinates": missing_coords,
            "missingNeighborhoodAfterFill": missing_nbhd,
            "assignedNeighborhood": assigned,
            "mappedInsideCity": mapped,
            "notMapped": total_records - mapped,
            "validCityPointButNotInAssignedNeighborhood": sum(1 for r in records if r["coordsValid"] and r["inCity"] and not r["pointMapped"]),
            "spatialNeighborhoodFills": spatial_filled,
            "missingNeighborhoodWithCoordinates": missing_nbhd_with_coords,
            "missingNeighborhoodFilledFromPoint": missing_nbhd_filled,
            "unassigned": unassigned,
            "fieldAssignedButPointOutsideCity": field_and_outside,
            "pointInDifferentNeighborhoodThanField": field_geom_conflict,
        },
        "aggregation": {
            "allYears": sorted(neighborhoods, key=lambda x: x["density"], reverse=True),
            "thresholds": thresholds,
            "quantileAnchors": quantile_anchors,
            "densitySummary": {
                "min": meta["densityMin"], "median": meta["densityMedian"], "max": meta["densityMax"],
                "mean": round(statistics.mean(densities), 3),
            },
            "areaTotalKm2": meta["areaTotalKm2"],
        },
        "independentSpotChecks": spot,
        "notes": [
            "Spot-check values above are computed independently from the cleaned record list, not from the map DOM.",
            "Area includes mapped water within census-derived neighborhood boundaries; do not call this a land-only density.",
            "The Farallones tract is excluded from the mapped study area; Visitacion Valley is included and has zero matching records in this snapshot.",
        ],
    }
    (OUT / "audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"records {total_records} works {total_works} neighborhoods {len(names)}")
    print(f"thresholds {thresholds} density {meta['densityMin']} / {meta['densityMedian']} / {meta['densityMax']}")
    print(f"missing year {missing_year}; missing coords {missing_coords}; missing nbhd {missing_nbhd}; fills {spatial_filled}")
    print(f"geo bytes {(OUT/'neighborhoods.geojson').stat().st_size:,}; streets {road_total} lines / {(OUT/'streets.geojson').stat().st_size:,} bytes")
    print("spot checks", json.dumps(spot, indent=2))


if __name__ == "__main__":
    main()
