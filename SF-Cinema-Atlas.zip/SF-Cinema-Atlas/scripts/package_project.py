#!/usr/bin/env python3
"""Package an offline-ready classroom project, avoiding recursive archives."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
root=Path(__file__).resolve().parent.parent
out=root/'downloads/SF-Cinema-Atlas.zip'
out.parent.mkdir(exist_ok=True)
allowed=['index.html','README.md','styles','src','data','vendor','assets','scripts','docs','screenshots']
with ZipFile(out,'w',ZIP_DEFLATED) as z:
 for item in allowed:
  p=root/item
  files=[p] if p.is_file() else p.rglob('*')
  for f in files:
   if f.is_file() and '__pycache__' not in f.parts and f.suffix not in ['.pyc']:
    z.write(f,'SF-Cinema-Atlas/'+str(f.relative_to(root)))
print(out, out.stat().st_size, 'bytes')
