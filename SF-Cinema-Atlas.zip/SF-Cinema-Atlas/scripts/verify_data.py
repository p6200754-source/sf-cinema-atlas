#!/usr/bin/env python3
"""Independent source-to-display audit; standard library only."""
import csv, json, hashlib, re
from pathlib import Path
from collections import Counter
ROOT=Path(__file__).resolve().parent.parent
raw=ROOT/'data/raw/film_locations_raw.csv'
rows=list(csv.DictReader(raw.open(encoding='utf-8-sig',newline='')))
seen=set(); retained=[]
for r in rows:
 key=tuple(r.items())
 if key not in seen:retained.append(r);seen.add(key)
a=json.loads((ROOT/'data/processed/atlas.json').read_text())
records=a['records']; assert len(retained)==len(records)
def clean(v):return re.sub(r'\s+',' ',(v or '').replace('\xa0',' ')).strip()
fields={'title':'Title','locations':'Locations','funFacts':'Fun Facts','director':'Director','writer':'Writer','productionCompany':'Production Company','distributor':'Distributor'}
for original,display in zip(retained,records):
 for target,source in fields.items():assert display[target]==clean(original[source]),(display['id'],source)
 assert display['yearRaw']==clean(original['Release Year'])
 assert display['actors']==[clean(original[f'Actor {i}']) for i in [1,2,3] if clean(original[f'Actor {i}'])]
 if display['coordsValid']:
  assert abs(display['lon']-float(original['Longitude']))<1e-7
  assert abs(display['lat']-float(original['Latitude']))<1e-7
 if display['neighborhoodSource']=='field':assert display['neighborhood']==clean(original['Analysis Neighborhood'])
 if display['pointMapped']:assert display['neighborhood']==display['spatialNeighborhood']
for n in a['neighborhoods']:
 recs=[r for r in records if r['neighborhood']==n['name']]
 assert len(recs)==n['records']
 assert len({r['workKey'] for r in recs})==n['works']
 assert abs(n['density']-len(recs)/n['areaKm2'])<.0001
known=[r for r in records if r['year'] is not None]
modern=[r for r in known if r['year']>=2000]
report={'original_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'raw_rows':len(rows),'exact_duplicates_removed':len(rows)-len(retained),'retained_rows':len(records),'source_text_fields_checked':list(fields),'all_41_neighborhood_aggregates':'PASS','coordinate_preservation':'PASS','known_year_records':len(known),'modern_records':len(modern),'modern_assigned_records':sum(bool(r['neighborhood']) for r in modern),'source_to_display':'PASS'}
(ROOT/'docs/source-verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
