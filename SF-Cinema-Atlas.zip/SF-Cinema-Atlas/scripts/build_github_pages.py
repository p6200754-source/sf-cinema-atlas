"""Build a self-contained Pages entry without changing source data."""
from pathlib import Path
import base64,json,re,shutil
root=Path(__file__).resolve().parent.parent
out=root/'github-pages';out.mkdir(exist_ok=True)
def js(s):return s.replace('</script','<\\/script')
css=(root/'styles/main.css').read_text()
def font(m):
 p=(root/'styles'/m[1]).resolve()
 return 'url("data:font/woff2;base64,'+base64.b64encode(p.read_bytes()).decode()+'")'
css=re.sub(r"url\(['\"]?(\.\./assets/fonts/[^)'\"]+)['\"]?\)",font,css)
d3=(root/'vendor/d3.v7.min.js').read_text();core=(root/'src/core.js').read_text()
practice=(root/'src/practice.js').read_text().replace('export async function','async function',1)
practice=practice.replace("await fetch('vendor/d3.v7.min.js').then(r=>{if(!r.ok)throw Error('Local D3 unavailable');return r.text();})",json.dumps(d3))
app=(root/'src/app.js').read_text();app=app[app.index('\n')+1:]
for name in ['atlas.json','neighborhoods.geojson','streets.geojson']:
 app=app.replace("d3.json('data/processed/"+name+"')",'Promise.resolve('+ (root/'data/processed'/name).read_text()+')')
app=app.replace("fetch('src/core.js').then(r=>{if(!r.ok)throw Error('Map source unavailable');return r.text();})",'Promise.resolve('+json.dumps(core)+')')
html=(root/'index.html').read_text()
html=re.sub(r'<link rel="stylesheet" href="styles/main.css[^\"]*">','<style>'+css+'</style>',html)
html=re.sub(r'<script defer src="vendor/d3.v7.min.js"></script><script defer src="src/core.js"></script><script type="module" src="src/app.js[^\"]*"></script>','',html)
html=html.replace('</body>','<script>'+js(d3)+'</script><script>'+js(core)+'</script><script type="module">'+js(practice+'\n'+app)+'</script></body>')
html=html.replace('downloads/SF-Cinema-Atlas.zip','SF-Cinema-Atlas.zip')
(out/'index.html').write_text(html)
shutil.copy2(root/'downloads/SF-Cinema-Atlas.zip',out/'SF-Cinema-Atlas.zip')
(out/'README.md').write_text('# SF Cinema Atlas\n\nInteractive San Francisco film-location choropleth map and editable D3 classroom exercises.\n\nData: https://data.sfgov.org/Culture-and-Recreation/Film-Locations-in-San-Francisco/yitu-d5am/about_data\n\nThe deployed index.html bundles the unchanged source datasets, D3 and fonts for reliable static hosting. Download SF-Cinema-Atlas.zip for the original modular source, data provenance, audit and licenses. No external film metadata or images are added.\n')
print('Self-contained index:',(out/'index.html').stat().st_size,'bytes')
