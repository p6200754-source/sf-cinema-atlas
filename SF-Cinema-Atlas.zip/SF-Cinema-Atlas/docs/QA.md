# Verification record — 2026-10-24

## Sources and calculations

- Fresh full downloads from official film, boundary and road endpoints byte-match all three saved raw snapshots. SHA256 values are in official-source-checksums.json.
- Re-ran process_data.py with Shapely, pyproj and pyshp against saved inputs. Output: 2,208 retained records, 352 title–year keys, 41 neighborhoods.
- Ran verify_data.py independently from the map: checked every displayed title, location, fact, director, writer, production/distribution field, actor list, year and valid coordinate against the raw CSV. All 41 neighborhood counts, distinct works and densities match recomputation.
- Source has 2,214 rows; only six exact duplicate rows removed in derived products. Raw file unchanged.
- Modern filter: 1,490 known-year records, 1,421 assigned. All-known-year exercise: 2,207 records, 2,071 assigned.
- Raw geography, rather than concept images, supplies map shapes. D3 polygon winding adjustment is a rendering convention only.

## Browser checks actually performed

- Local static site served beneath `/cinema-atlas/`, exercising a GitHub Pages-like subpath.
- Desktop 1440×900, projection-size 1280×720 and mobile 390×844: visual review and document-width checks; no page-level horizontal overflow observed.
- Neighborhood selection opens real records. North Beach: 202 records, 99 title–year keys, 157.4 records/km² (rounded display).
- The Phone/Jexi, 2019: opened its seven North Beach records, local map and matching location descriptions from the snapshot.
- Focus map and full-city reset work. Marker/text sizes remain bounded when zooming; numbered badges are offset with leaders rather than hidden when points are close. No routes are inferred.
- Release-year dropdown recalculates map/coverage counts and preserves fixed thresholds. Zero state has a separate color.
- Task 1 manually edited to schemeOranges: map and legend change together; runtime output passes goal checking.
- Task 2 manually edited to 2000: output totals match independent source recomputation; goal checking passes.
- Invalid `const broken = ;` produces a visible syntax-error message outside the preview. Reset restores working code and map.
- Rebuild, per-task edit persistence, navigation and real-source lesson panels reviewed.
- Real screenshot files are saved in screenshots/; no concept art used as proof of the implementation.

## Limits

- Browser review is on the available Chromium-based in-app browser; Safari/Firefox and screen-reader behavior have not been comprehensively audited.
- Some source records lack location/year/coordinates or contain field/coordinate conflicts. These are disclosed, not repaired with invented facts. Conflict/outside points remain in data but are not displayed at misleading positions.
- Neighborhood area includes mapped water. Street texture is modern auxiliary context.
- Close geographic markers can still coincide physically; true dots stay in place while numbered badges are offset with leaders, and the record list remains the precise selection mechanism.
- The editor is a simple textarea with navigation, not a full IDE. It has no syntax coloring or multi-file editing.
- Sandboxing restricts DOM/network capabilities but cannot promise recovery from all malicious or infinite-loop JavaScript; no such code was run during verification.
- Final slide deck and member names require the group. Presentation outline supplied.
- No public deployment or GitHub repository push has occurred.

## Workspace isolation

Other work was changing the parent directory's implementation files during development. This deliverable is self-contained in cinema-atlas/ to avoid overwriting those changes. Use this folder as the root of the delivered version.

## Refinement checks — 2026-10-25

- Confirmed 41 SVG shapes have no native rectangular outline; selected geometry remains one consistent path, and keyboard focus has a custom dashed boundary.
- Dope Queens / Tenderloin: all six numbered groups visible in both maps. After zooming, badge radius stays 10px and closest badge centers are more than 25px apart.
- Four short lesson excerpts visible by default, full implementation closed, bilingual speaking notes present.
- Locate selects the actual palette/year declaration. Both manual task edits run and complete; Task 2 still reports 1,490 / 1,421.
- Desktop 1440×900, projector 1280×720, mobile 390×844 reviewed; no page-level horizontal overflow observed. Long Financial District/South Beach title wraps inside its ticket.
- Re-ran source-to-display checks and all official raw-source SHA256 comparisons; unchanged.
