# Classroom workflow: local editing only

The public Your turn page no longer contains an editable source area, Run/Reset/Export controls, iframe execution, task completion checking or editor storage. It links to the official DataSF dataset and CSV export, the VS Code starter ZIP, and the full source ZIP. It retains two task descriptions and a genuine all-year reference map. Homepage and the static Behind the map walkthrough are retained.

Students unzip the starter, open its folder in VS Code, use Live Server to serve index.html, edit map.js, save, and inspect the local browser. Task 1 changes five colors; task 2 changes YEAR and YEAR_MODE. data.js reads the raw local CSV, removes exact all-field duplicates, keeps source neighborhoods, and spatially fills only unambiguous missing assignments using source census tracts. Original rows remain preserved. Bounds, areas and D3 are bundled. All-year baseline: 2,214 raw rows, 6 duplicates removed, 2,208 retained, 8 spatial fills, 2,072 assigned. All 41 default fills match the website reference. Browser verification also passed 2019 with mixed HEX/RGB/RGBA/HSL: 131 records / 128 assigned.

Fresh official downloads may have changed since the website snapshot. Replace data/film_locations.csv without editing its column names, then refresh. No invented rows, fixed record totals, posters or external film information are used.

Presentation update: replace the earlier online Run-code demonstration with a brief explanation of the downloads and local workflow. The previously generated presentation PDF describes the earlier editor and has not been revised by this website-only update.

发布更新沿用 https://p6200754-source.github.io/sf-cinema-atlas/ ，现有二维码继续有效。
