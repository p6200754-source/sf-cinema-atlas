# SF Cinema Atlas — presentation outline

Team names: to be filled by the group. Timing below is a suggestion, not a course requirement.

1. **Question and chart form.** Where are the dataset's recorded film locations concentrated? A choropleth compares regions through ordered color. Points answer where an individual location is.
2. **Source and unit.** DataSF yitu-d5am, saved full snapshot. One row is a location record, not one film or one shooting event. No external movie images or metadata. Release year differs from filming year.
3. **Explore.** Show All years, read the density legend, select North Beach, open a title and numbered location. Use Focus map if points are close. Compare a neighborhood's record total with its records/km².
4. **Four real D3 ideas.** Collect: filter and rollup; Project: geoMercator and geoPath; Color: scaleThreshold and shared legend; Connect: keyed join plus mouse/keyboard selection.
5. **Task 1.** Students manually replace schemeBlues with schemeOranges, then Run. Map and legend change; counts do not. Ask what the darkest area means.
6. **Task 2.** Students manually set START_YEAR to 2000, then Run. Expected snapshot totals: 1,490 known-year records, 1,421 assigned. Ask students to find one qualifying title and year in Explore.
7. **Limitations.** Recorded coverage is incomplete. Area includes mapped water. Original field/coordinate conflicts and missing data are disclosed. Modern streets are context, not historical reconstruction. Fixed thresholds support time comparison.
8. **Submission.** Export edited code and screenshot according to the instructor's chosen channel. Each team member also submits the required group information, one-sentence data/design description, complete source, running screenshot and presentation files.

Suggested one-sentence description:
Using DataSF film-location records, this D3 choropleth compares recorded locations per square kilometre across San Francisco analysis neighborhoods, with linked title and location archives.
