# Free JavaScript workspace — 2026-10-25

The classroom editor contains a single fully editable `map.js`. Students can change the palette, year, filters, D3 scales and drawing logic. No task-answer comparison or palette/year whitelist gates execution. D3 API names must still exist and JavaScript syntax must be valid.

The preview supplies `records`, `features`, `thresholds`, `width`, `height`, `svg`, `layer`, D3 v7 and `AtlasCore`. The initial map.js shows filtering, aggregation, projection, coloring and drawing. Optional `finish({...})` adds streets, legend and a summary calculated from supplied filtered records/stats. Custom code may draw directly without calling it. Exported map.js uses these supplied dependencies; the complete ZIP contains the host.

Code runs in an opaque sandboxed iframe with local bundled dependencies, no network requests or parent-page access. Each run is prepared in a candidate frame. A synchronous runtime or syntax error retains the previous successful preview. Task edits save separately in browser storage (`sf-cinema-map-v3`); older saved settings are migrated into complete code and older storage keys are preserved. Reset affects the current task only.

Browser checks: custom five-color array plus 2008 filter ran with 1,369 filtered records / 1,324 assigned; direct D3 circle drawing with no finish() ran; invalid syntax reported an error while retaining that circle; schemeYlOrBr[5] ran. Source data files were not changed.

## Revised classroom template

The current template uses palette (default matches Explore), YEAR (null for all records or a specific release year), and YEAR_MODE (exact / since). No commented duplicate const snippets are inserted. The whole map.js remains editable. Both views use AtlasCore.filterRecords, aggregate, makeProjection, makeColorScale and drawNeighborhoods. All-year filtering includes the source record without a known year, as Explore does. The sandbox adds street context, selected outlines, native neighborhood data tips, labels and zoom controls. It does not include the homepage film archive.

Revised drafts save separately under sf-cinema-map-v4; older v3 drafts remain stored. Browser verification: all 41 default polygon fills match Explore exactly; all years 2,208 / 2,072 assigned; 2019 exact with mixed HEX/RGB/RGBA/HSL 131 / 128 assigned; 2010 onward 1,357 / 1,313 assigned. Only presentation/editor code changed, not data.
